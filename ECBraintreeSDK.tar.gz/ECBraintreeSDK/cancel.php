<?php require_once("incl.header.php"); ?>

		<div class="container-fluid">

            <div class="row">         

              	<div class="col-xs-12">
                	<div style="text-align:center;">
                   		<h3>The transaction was cancelled.</h3>
                       	<br/>
	                	<br/>
						<br/>
                	</div>
                </div>
  				
  				<div class="col-xs-12">
                	<div style="text-align:center;">
                   		<h3>Return to <a href='index.php'>Home Page</a></h3>
                	</div>
                </div>
                
  			</div>
		</div>
		
<?php require_once("incl.footer.php"); ?>